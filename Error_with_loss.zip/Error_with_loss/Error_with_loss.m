clear all;
close all;
clc;

% Variation of State Estimation error with Measurement Loss
% All the loads are single phase loads


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%% PREDEFINED VALUE S%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
min_power = 0.25; 	%Minimum power of each load
max_power = 8; 		%Maximum power of each load
V_un 		= [0.1, 0.1, 0.5, 0.5];
P_un 		= [0.2, 0.5, 0.8, 1];
data_loss 	= [0 5 10 15 20 25]; 	%Data loss percentage (%)
err_p 		= 4; 	%Number of phases considered for the error calculations
n_MC 		= 500; 	%Number of Monte-Carlo Simulations considered for each case

Transformer_rating = 400;	
it =1;
Sigma_P = P_un(1,1);
Sigma_V = V_un(1,1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%% Network Parameters %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
secLengths      = cell(8,1);
secCustomers    = cell(8,1);

%SECTIONA 1
secCustomers{1} =[3 1 2 2 2 2 2 2 2 1]; %No of customers connected
secLengths{1}   =[36 19 21 27 24 26 28 23 21 22]; 	%Distance to each node

%SECTION 2
secCustomers{2} =[0 0 1 1];				%No of customers connected
secLengths{2}   =[36 30 30 32]; 					%Distance to each node

%SECTION 3
secCustomers{3} =[2 2 2 2 2 1 1 2 2 1]; %No of customers connected
secLengths{3}   =[25 25 30 25 26 10 9 11 12 9]; 	%Distance to each node

%SECTION 4
secCustomers{4} =[1 1 1 1 1 1]; 		%No of customers connected
secLengths{4}   =[27 28 29 25 24 26]; 				%Distance to each node

%SECTION 5
secCustomers{5} =[0 0 0 0 2 1 2 1]; 	%No of customers connected
secLengths{5}   =[22 30 33 28 23 24 25 29]; 		%Distance to each node

%SECTION 6
secCustomers{6} =[0 0 2 2 2 2 4 3 3]; 	%No of customers connected
secLengths{6}   =[28 27 20 20 23 24 20 25 24]; 		%Distance to each node

%SECTION 7
secCustomers{7} =[0 0 1 2 2 2 2 2 1]; 	%No of customers connected
secLengths{7}   =[44 29 30 25 27 22 28 23 30]; 		%Distance to each node

%SECTION 8
secCustomers{8} =[2 2 2 2 1 3]; 		%No of customers connected
secLengths{8}   =[30 28 29 24 28 15]; 				%Distance to each node
		
%Calculating total number of loads
totalnumload	= sum(secCustomers{1}) + sum(secCustomers{2}) + sum(secCustomers{3}) ... 
+ sum(secCustomers{4}) + sum(secCustomers{5}) + sum(secCustomers{6}) ... 
+ sum(secCustomers{7}) + sum(secCustomers{8});

c=[0 0 13 0 0 34 0 50]; 	%Connection point when starting new Line

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%% Start OpenDSS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for data_loss_case = 1:6
	for Loading = 0.1:0.05:1
		Vm_error_inf_kron	=0;
		Vm_error_2_kron		=0;
		Im_error_inf_kron	=0;
		Im_error_2_kron		=0;
			
		Vang_error_inf_kron	=0;
		Vang_error_2_kron	=0;
		Iang_error_inf_kron	=0;
		Iang_error_2_kron	=0;
		
		Vm_error_inf_our	=0;
		Vm_error_2_our		=0;
		Im_error_inf_our	=0;
		Im_error_2_our		=0;
			
		Vang_error_inf_our	=0;
		Vang_error_2_our	=0;
		Iang_error_inf_our	=0;
		Iang_error_2_our	=0;
		
		for MC = 1:n_MC
			%Calculating load values for each loding...
			powerfactor 		= round(0.9 + 0.1*rand(totalnumload,1),3);
			mean_pf 			= mean(powerfactor);
			Total_active_power 	= Transformer_rating*Loading*mean_pf;
			loadpower			= round(randfixedsum(totalnumload,1,Total_active_power,min_power,max_power),1);
			
			%Creating single phase loads for each customer ...
			for v = 1:totalnumload
				f = normrnd(1,0.1,[1,3]); %Generate normally distributed random variable with mean 1 and std=0.2
				Load_power_Ac(v,:) = f.*(loadpower(v)/sum(f)); %Generate signle phase load power values
			end
			
			%Calculating PV capacities for each loading...
			pvkw	= Loading*[2 6 4.2 5 4.2 4.2 2 10 4 5.4 5 3.3 5 2.6 3.5 17 10 5.3 4.8 6.9 4.3];
			pvkva 	= pvkw/sqrt(1-0.44^2);
			pvphase	= randi(3,length(pvkw),1);
			pvbus	= randi(62,length(pvkw),1);
			
			if exist('DSSStartOK','var')==0
				[DSSStartOK, DSSObj, DSSText] = DSSStartup(cd);
			end

			DSSStartOK;
			if DSSStartOK	
			DSSText.command = 'Clear';

			DSSText.command = 'new circuit.Feeder01 basekv=11 pu=1.05 phases=3 bus1=SourceBus Angle=30';    
			 
			DSSText.command = 'New Wiredata.ABC70Ph GMR=0.0035937 DIAM=9.9 RDC=0.443';
			DSSText.command = '~ Runits=km radunits=mm gmrunits=m';
			DSSText.command = 'New Wiredata.ABC70Ne GMR=0.0034485 DIAM=9.5 RDC=0.63';
			DSSText.command = '~ Runits=km radunits=mm gmrunits=m';
			 
			DSSText.command = 'New Linegeometry.ABC70 nconds=4 nphases=3';
			DSSText.command = '~ cond=1 Wire=ABC70Ph x=0.00675 h=8.00675 units=m';
			DSSText.command = '~ cond=2 Wire=ABC70Ph x=0.05235 h=8.00675 units=m';
			DSSText.command = '~ cond=3 Wire=ABC70Ph x=0.01985 h=7.9869  units=m';
			DSSText.command = '~ cond=4 Wire=ABC70Ne x=0.01985 h=8       units=m';
			DSSText.command = 'New Transformer.TR1 Buses=[SourceBus.1.2.3.0, busno_0.1.2.3.4] Phases=3 Conns=[Delta Wye] kVs= [11 0.413] kVAs=[400 400] XHL=10 Rneut=0.5'; %%Windings=2 %%%%%DSSText.command = 'New Linecode.ALXLPE R1=0.35 X1=0.026 R0=.1784 X0=.4047 C1=3.4 C0=1.6 Units=km';

			% define lines for all bus path with  transmission line
			k	=1;  
			p	=1;
			feders_starts	=[];
			separation		=[];
			
			for i=1:8
				%for each i value, length1 = length_i
                length1 = secLengths{i};
				%for each i value, Costomers = node_no_customers_i
                Customers = secCustomers{i};

				%%%%% line connecton bus blength1)-1)];
				busnum=[c(i) k:1:(k+length(length1)-1)];
				
				feders_starts=[feders_starts k];
				separation=[separation c(i)];
				
				for j=1:length(length1)
				%%%% define the transmission line 
					DSSText.command = strcat('New Line.LINE',num2str(k),' Bus1=busno_',num2str(busnum(j)),'.1.2.3.4 Bus2=busno_',num2str(busnum(j+1)),'.1.2.3.4 Geometry=ABC70 Length=',num2str(length1(j)),' Units=m');
					%%%%% define load connected to j+1 bus bar
					if(Customers(j)~=0)
						 for g=1:Customers(j)
							DSSText.command = strcat('New Load.LOAD',num2str(p),'_P1',' Bus1=busno_',num2str(busnum(j+1)),'.1.4 kV=0.238 kW=',num2str(Load_power_Ac(1,1)),' PF=',num2str(powerfactor(p)),' phases=1');
							DSSText.command = strcat('New Load.LOAD',num2str(p),'_P2',' Bus1=busno_',num2str(busnum(j+1)),'.2.4 kV=0.238 kW=',num2str(Load_power_Ac(1,2)),' PF=',num2str(powerfactor(p)),' phases=1');
							DSSText.command = strcat('New Load.LOAD',num2str(p),'_P3',' Bus1=busno_',num2str(busnum(j+1)),'.3.4 kV=0.238 kW=',num2str(Load_power_Ac(1,3)),' PF=',num2str(powerfactor(p)),' phases=1');
							p=p+1;
						  end
					end
					k=k+1;
			   end
			end
			nofbus			= k-1;
			feders_starts	= [feders_starts nofbus];

			%%% adding Pv panel
			DSSText.command = 'New XYCurve.MyPvsT npts=4 xarray=[0 25 75 100] yarray=[1.0 1.0 1.0 1.0]';
			DSSText.command = 'New XYCurve.MyEff npts=4 xarray=[0.1 0.2 0.4 1.0] yarray=[1.0 1.0 1.0 1.0]';

			for y=1:length(pvkw)
				DSSText.command = strcat('New PVSystem.PV',num2str(y),' phases=1 Bus1=busno_',num2str(pvbus(y)),'.',num2str(pvphase(y)),'.4 kv=0.24 kVA=',num2str(pvkva(y)),' irrad=1 Pmpp=',num2str(pvkw(y)),' PF=1 effcurve=MyEff P-Tcurve=MyPvsT');
			end

			DSSText.command = 'Set voltagebases=[11 0.413]';
			DSSText.command = 'Calcvoltagebases';
				
			DSSText.command = 'Solve';
			%DSSText.command = 'Show power kva elem';

			for i	= 0:(nofbus)
				im	= strcat('busno_',num2str(i));
				DSSObj.ActiveCircuit.Buses(im);
				puvoltage(i+1,:) = DSSObj.ActiveCircuit.ActiveBus.puVoltages; 
			end

			%EXTRACTING VOLTAGE (COMPLEX) AT EACH NODE 0-62 NODES TOTAL = 63 NODES
			for i=0:(nofbus)
				LF_Ac_V(i+1,1) = (puvoltage(i+1,1)+1i*puvoltage(i+1,2))*0.413*10^3/sqrt(3); 
				LF_Ac_V(i+1,2) = (puvoltage(i+1,3)+1i*puvoltage(i+1,4))*0.413*10^3/sqrt(3); 
				LF_Ac_V(i+1,3) = (puvoltage(i+1,5)+1i*puvoltage(i+1,6))*0.413*10^3/sqrt(3); 
				LF_Ac_V(i+1,4) = (puvoltage(i+1,7)+1i*puvoltage(i+1,8))*0.413*10^3/sqrt(3); 
            end
			
			LF_V = LF_Ac_V;				%Actual Voltage States of the Network
			save('LF_V.mat','LF_V');		
			Uref = round(mean(mean(abs(LF_Ac_V(:,1:3)))),0)+1;

			%%%%%%%%%%%%%%%%%%%%%%%%% EXTRACT P AND Q %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
			for line=1:(nofbus)
				DSSText.Command		= strcat('select Line.LINE',num2str(line));
				LF_Ac_PQ(line,:) 	= DSSObj.ActiveCircuit.ActiveElement.power;
				LF_Ac_P(line,:)		= 1000.*[LF_Ac_PQ(line,1),LF_Ac_PQ(line,3),LF_Ac_PQ(line,5)];
				LF_Ac_Q(line,:) 	= 1000.*[LF_Ac_PQ(line,2),LF_Ac_PQ(line,4),LF_Ac_PQ(line,6)];
			end
			S_Ac	= LF_Ac_P + 1i*LF_Ac_Q;	%Actual complex power matrix

			%%%%%%%%%%%%%%%%%%%%%%%%% EXTRACT I %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
			for line	= 1:(nofbus)
				DSSText.Command = strcat('select Line.LINE',num2str(line));
				temp 			= DSSObj.ActiveCircuit.ActiveElement.currents;
				LF_Ac_I(line,1) = temp(1,1)+1i*temp(1,2);
				LF_Ac_I(line,2) = temp(1,3)+1i*temp(1,4);
				LF_Ac_I(line,3) = temp(1,5)+1i*temp(1,6);
				LF_Ac_I(line,4) = temp(1,7)+1i*temp(1,8);
            end
            
            end
			%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
			%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
			%%%%%%%%%%%%%%%% End of the Actual load flow analysis %%%%%%%%%%%%%%%%%%%
			%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
			%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
			
			%Generating data loss matrix...
			n_of_dataloss 	= round(totalnumload*3*data_loss(1,data_loss_case)/100); %=No of zeros
			temp2 			= ones(totalnumload*3,1);
			temp2(1:n_of_dataloss,1)	= 0;
			temp3 		= reshape(temp2(randperm(totalnumload*3)),totalnumload,3);
			Mes_points 	= temp3;
			Power_Availability = temp3;
			
			%Assign random values for unknown power measurements...
			Received_power_vals = Load_power_Ac.*Power_Availability;
			power_diff 			= sum(Load_power_Ac) - sum(Received_power_vals);
			
            loss_each_phase = [92 92 92] - sum(Power_Availability);
			
			%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
			%%%%%%%%%%%%%%% Sudo values assign for unknown power values %%%%%%%%%%%%
			%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
			%Phase 1
			if loss_each_phase(1,1) ~= 0
				sudo_power_p1 = round(randfixedsum(loss_each_phase(1,1),1,power_diff(1,1),0,max_power),1);
                Received_power_vals(Received_power_vals(:,1)==0,1) = sudo_power_p1;
            end
			
			%Phase 2
            if loss_each_phase(1,2) ~= 0
				sudo_power_p2 = round(randfixedsum(loss_each_phase(1,2),1,power_diff(1,2),0,max_power),1);
                Received_power_vals(Received_power_vals(:,2)==0,2) = sudo_power_p2;
            end
            
			%Phase 3
            if loss_each_phase(1,3) ~= 0
				sudo_power_p3 = round(randfixedsum(loss_each_phase(1,3),1,power_diff(1,3),0,max_power),1);
                Received_power_vals(Received_power_vals(:,3)==0,3) = sudo_power_p3;
            end
			%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
			%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
			%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
			%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
			%%%%%%%%%%%%%%%%%% Load Flow Analysis for Received Power Values %%%%%%%%%%%%%%%%%%
			%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
			%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
			%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
			
			if exist('DSSStartOK','var')==0
				[DSSStartOK, DSSObj, DSSText] = DSSStartup(cd);
			end

			DSSStartOK;
			if DSSStartOK	
			DSSText.command = 'Clear';

			DSSText.command = 'new circuit.Feeder01 basekv=11 pu=1.05 phases=3 bus1=SourceBus Angle=30';    
			 
			DSSText.command = 'New Wiredata.ABC70Ph GMR=0.0035937 DIAM=9.9 RDC=0.443';
			DSSText.command = '~ Runits=km radunits=mm gmrunits=m';
			DSSText.command = 'New Wiredata.ABC70Ne GMR=0.0034485 DIAM=9.5 RDC=0.63';
			DSSText.command = '~ Runits=km radunits=mm gmrunits=m';
			 
			DSSText.command = 'New Linegeometry.ABC70 nconds=4 nphases=3';
			DSSText.command = '~ cond=1 Wire=ABC70Ph x=0.00675 h=8.00675 units=m';
			DSSText.command = '~ cond=2 Wire=ABC70Ph x=0.05235 h=8.00675 units=m';
			DSSText.command = '~ cond=3 Wire=ABC70Ph x=0.01985 h=7.9869  units=m';
			DSSText.command = '~ cond=4 Wire=ABC70Ne x=0.01985 h=8       units=m';
			DSSText.command = 'New Transformer.TR1 Buses=[SourceBus.1.2.3.0, busno_0.1.2.3.4] Phases=3 Conns=[Delta Wye] kVs= [11 0.413] kVAs=[400 400] XHL=10 Rneut=0.5'; %%Windings=2 %%%%%DSSText.command = 'New Linecode.ALXLPE R1=0.35 X1=0.026 R0=.1784 X0=.4047 C1=3.4 C0=1.6 Units=km';

			% define lines for all bus path with  transmission line
			k	= 1; 
			p	= 1;
			feders_starts 	=[];
			separation		=[];
			
			for i=1:8
				%for each i value, length1 = length_i
                length1 = secLengths{i};
				%for each i value, Costomers = node_no_customers_i
                Customers = secCustomers{i};

				%%%%% line connecton bus blength1)-1)];
				busnum	= [c(i) k:1:(k+length(length1)-1)];
				
				feders_starts	= [feders_starts k];
				separation		= [separation c(i)];
				
				for j=1:length(length1)
				% define the transmission line 
					DSSText.command = strcat('New Line.LINE',num2str(k),' Bus1=busno_',num2str(busnum(j)),'.1.2.3.4 Bus2=busno_',num2str(busnum(j+1)),'.1.2.3.4 Geometry=ABC70 Length=',num2str(length1(j)),' Units=m');
					% define load connected to j+1 bus bar
					if(Customers(j)~=0)
						 for g=1:Customers(j)
							DSSText.command = strcat('New Load.LOAD',num2str(p),'_P1',' Bus1=busno_',num2str(busnum(j+1)),'.1.4 kV=0.238 kW=',num2str(Received_power_vals(1,1)),' PF=',num2str(powerfactor(p)),' phases=1');
							DSSText.command = strcat('New Load.LOAD',num2str(p),'_P2',' Bus1=busno_',num2str(busnum(j+1)),'.2.4 kV=0.238 kW=',num2str(Received_power_vals(1,2)),' PF=',num2str(powerfactor(p)),' phases=1');
							DSSText.command = strcat('New Load.LOAD',num2str(p),'_P3',' Bus1=busno_',num2str(busnum(j+1)),'.3.4 kV=0.238 kW=',num2str(Received_power_vals(1,3)),' PF=',num2str(powerfactor(p)),' phases=1');
							p	= p+1;
						  end
					end
					k	= k+1;
			   end
			end
			nofbus=k-1;
			feders_starts=[feders_starts nofbus];

			%%% adding Pv panel
			DSSText.command = 'New XYCurve.MyPvsT npts=4 xarray=[0 25 75 100] yarray=[1.0 1.0 1.0 1.0]';
			DSSText.command = 'New XYCurve.MyEff npts=4 xarray=[0.1 0.2 0.4 1.0] yarray=[1.0 1.0 1.0 1.0]';

			for y=1:length(pvkw)
				DSSText.command = strcat('New PVSystem.PV',num2str(y),' phases=1 Bus1=busno_',num2str(pvbus(y)),'.',num2str(pvphase(y)),'.4 kv=0.24 kVA=',num2str(pvkva(y)),' irrad=1 Pmpp=',num2str(pvkw(y)),' PF=1 effcurve=MyEff P-Tcurve=MyPvsT');
			end

			DSSText.command = 'Set voltagebases=[11 0.413]';
			DSSText.command = 'Calcvoltagebases';
				
			DSSText.command = 'Solve';
			
			%%%%%%%%%%%%%%%%%%%%%%%%% EXTRACT P AND Q %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
			for line=1:(nofbus)
				DSSText.Command		= strcat('select Line.LINE',num2str(line));
				LF_Re_PQ(line,:) 	= DSSObj.ActiveCircuit.ActiveElement.power;
				LF_Re_P(line,:)		= 1000.*[LF_Re_PQ(line,1),LF_Re_PQ(line,3),LF_Re_PQ(line,5)];
				LF_Re_Q(line,:)		= 1000.*[LF_Re_PQ(line,2),LF_Re_PQ(line,4),LF_Re_PQ(line,6)];
			end
			
			S_Re	= LF_Re_P + 1i*LF_Re_Q;
			LF_P 	= LF_Re_P;
			LF_Q 	= LF_Re_Q;
			
			save('LF_P.mat','LF_P');
			save('LF_Q.mat','LF_Q');
            end
			%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
			%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
			%%%%%%%%%%%%%%%% End of the Received load flow analysis %%%%%%%%%%%%%%%%%
			%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
			%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
			
			
			%%%%%%%%%%%%%%%%%%%%%%%%%%% STATE ESTIMATION - Krons Method%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
			%%%%%%%%%%%%%%%%%%%%%%%%%%% STATE ESTIMATION - Krons Method%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
			%%%%%%%%%%%%%%%%%%%%%%%%%%% STATE ESTIMATION - Krons Method%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
			%%%%%%%%%%%%%%%%%%%%%%%%%%% STATE ESTIMATION - Krons Method%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
			clc;
			SE_V_kron(1,1:3) = LF_Ac_V(1,1:3);
			SE_V_kron(1,4) = 0;

			%STATE ESTIMATION   
			line_length	= [secLengths{1},secLengths{2},secLengths{3},secLengths{4},secLengths{5},secLengths{6},secLengths{7},secLengths{8}];

			for line=1:62
				[SE_V_kron,Y_red,Y] = SE(SE_V_kron,Mes_points(line,:),line,line_length(1,line),Uref,Sigma_P,Sigma_V,1); %ESTIMATING VOLTAGE MAGNITUDES AND ANGLES
				switch line
					case 11
						SE_I_kron(line,1) = conj(S_Ac(line,1)/SE_V_kron(1,1));
						SE_I_kron(line,2) = conj(S_Ac(line,2)/SE_V_kron(1,2));
						SE_I_kron(line,3) = conj(S_Ac(line,3)/SE_V_kron(1,3));
					case 15
						SE_I_kron(line,1) = conj(S_Ac(line,1)/SE_V_kron(14,1));
						SE_I_kron(line,2) = conj(S_Ac(line,2)/SE_V_kron(14,2));
						SE_I_kron(line,3) = conj(S_Ac(line,3)/SE_V_kron(14,3));
					case 25
						SE_I_kron(line,1) = conj(S_Ac(line,1)/SE_V_kron(1,1));
						SE_I_kron(line,2) = conj(S_Ac(line,2)/SE_V_kron(1,2));
						SE_I_kron(line,3) = conj(S_Ac(line,3)/SE_V_kron(1,3));
					case 31
						SE_I_kron(line,1) = conj(S_Ac(line,1)/SE_V_kron(1,1));
						SE_I_kron(line,2) = conj(S_Ac(line,2)/SE_V_kron(1,2));
						SE_I_kron(line,3) = conj(S_Ac(line,3)/SE_V_kron(1,3));
					case 39
						SE_I_kron(line,1) = conj(S_Ac(line,1)/SE_V_kron(35,1));
						SE_I_kron(line,2) = conj(S_Ac(line,2)/SE_V_kron(35,2));
						SE_I_kron(line,3) = conj(S_Ac(line,3)/SE_V_kron(35,3));
					case 48
						SE_I_kron(line,1) = conj(S_Ac(line,1)/SE_V_kron(1,1));
						SE_I_kron(line,2) = conj(S_Ac(line,2)/SE_V_kron(1,2));
						SE_I_kron(line,3) = conj(S_Ac(line,3)/SE_V_kron(1,3));
					case 57
						SE_I_kron(line,1) = conj(S_Ac(line,1)/SE_V_kron(51,1));
						SE_I_kron(line,2) = conj(S_Ac(line,2)/SE_V_kron(51,2));
						SE_I_kron(line,3) = conj(S_Ac(line,3)/SE_V_kron(51,3));
					otherwise
						SE_I_kron(line,1) = conj(S_Ac(line,1)/SE_V_kron(line,1));
						SE_I_kron(line,2) = conj(S_Ac(line,2)/SE_V_kron(line,2));
						SE_I_kron(line,3) = conj(S_Ac(line,3)/SE_V_kron(line,3));
				end
				SE_I_kron(line,4) = -1*(SE_I_kron(line,1)+SE_I_kron(line,2)+SE_I_kron(line,3));
				Delta_V   = inv(Y)*SE_I_kron(line,:)';
				switch line
					case 11
						SE_V_kron(line+1,4) = SE_V_kron(1,4) - Delta_V(4,1);
					case 15
						SE_V_kron(line+1,4) = SE_V_kron(14,4) - Delta_V(4,1);
					case 25
						SE_V_kron(line+1,4) = SE_V_kron(1,4) - Delta_V(4,1);
					case 31
						SE_V_kron(line+1,4) = SE_V_kron(1,4) - Delta_V(4,1);
					case 39
						SE_V_kron(line+1,4) = SE_V_kron(35,4) - Delta_V(4,1);
					case 48
						SE_V_kron(line+1,4) = SE_V_kron(1,4) - Delta_V(4,1);
					case 57
						SE_V_kron(line+1,4) = SE_V_kron(51,4) - Delta_V(4,1);
					otherwise
						SE_V_kron(line+1,4) = SE_V_kron(line,4) - Delta_V(4,1);
				end
			end
			
			%%%%%%%%%%%%%%%%%%%%%%%%%%% STATE ESTIMATION - Our Method%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
			%%%%%%%%%%%%%%%%%%%%%%%%%%% STATE ESTIMATION - Our Method%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
			%%%%%%%%%%%%%%%%%%%%%%%%%%% STATE ESTIMATION - Our Method%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
			%%%%%%%%%%%%%%%%%%%%%%%%%%% STATE ESTIMATION - Our Method%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
			clc;
			SE_V_our(1,1:3) = LF_Ac_V(1,1:3);
			SE_V_our(1,4) = 0;

			%STATE ESTIMATION   
			line_length	= [secLengths{1},secLengths{2},secLengths{3},secLengths{4},secLengths{5},secLengths{6},secLengths{7},secLengths{8}];

			for line=1:62
				[SE_V_our,Y_red,Y] = SE(SE_V_our,Mes_points(line,:),line,line_length(1,line),Uref,Sigma_P,Sigma_V,2); %ESTIMATING VOLTAGE MAGNITUDES AND ANGLES
				switch line
					case 11
						SE_I_our(line,1) = conj(S_Ac(line,1)/SE_V_our(1,1));
						SE_I_our(line,2) = conj(S_Ac(line,2)/SE_V_our(1,2));
						SE_I_our(line,3) = conj(S_Ac(line,3)/SE_V_our(1,3));
					case 15
						SE_I_our(line,1) = conj(S_Ac(line,1)/SE_V_our(14,1));
						SE_I_our(line,2) = conj(S_Ac(line,2)/SE_V_our(14,2));
						SE_I_our(line,3) = conj(S_Ac(line,3)/SE_V_our(14,3));
					case 25
						SE_I_our(line,1) = conj(S_Ac(line,1)/SE_V_our(1,1));
						SE_I_our(line,2) = conj(S_Ac(line,2)/SE_V_our(1,2));
						SE_I_our(line,3) = conj(S_Ac(line,3)/SE_V_our(1,3));
					case 31
						SE_I_our(line,1) = conj(S_Ac(line,1)/SE_V_our(1,1));
						SE_I_our(line,2) = conj(S_Ac(line,2)/SE_V_our(1,2));
						SE_I_our(line,3) = conj(S_Ac(line,3)/SE_V_our(1,3));
					case 39
						SE_I_our(line,1) = conj(S_Ac(line,1)/SE_V_our(35,1));
						SE_I_our(line,2) = conj(S_Ac(line,2)/SE_V_our(35,2));
						SE_I_our(line,3) = conj(S_Ac(line,3)/SE_V_our(35,3));
					case 48
						SE_I_our(line,1) = conj(S_Ac(line,1)/SE_V_our(1,1));
						SE_I_our(line,2) = conj(S_Ac(line,2)/SE_V_our(1,2));
						SE_I_our(line,3) = conj(S_Ac(line,3)/SE_V_our(1,3));
					case 57
						SE_I_our(line,1) = conj(S_Ac(line,1)/SE_V_our(51,1));
						SE_I_our(line,2) = conj(S_Ac(line,2)/SE_V_our(51,2));
						SE_I_our(line,3) = conj(S_Ac(line,3)/SE_V_our(51,3));
					otherwise
						SE_I_our(line,1) = conj(S_Ac(line,1)/SE_V_our(line,1));
						SE_I_our(line,2) = conj(S_Ac(line,2)/SE_V_our(line,2));
						SE_I_our(line,3) = conj(S_Ac(line,3)/SE_V_our(line,3));
				end
				SE_I_our(line,4) = -1*(SE_I_our(line,1)+SE_I_our(line,2)+SE_I_our(line,3));
				Delta_V   = inv(Y)*SE_I_our(line,:)';
				switch line
					case 11
						SE_V_our(line+1,4) = SE_V_our(1,4) - Delta_V(4,1);
					case 15
						SE_V_our(line+1,4) = SE_V_our(14,4) - Delta_V(4,1);
					case 25
						SE_V_our(line+1,4) = SE_V_our(1,4) - Delta_V(4,1);
					case 31
						SE_V_our(line+1,4) = SE_V_our(1,4) - Delta_V(4,1);
					case 39
						SE_V_our(line+1,4) = SE_V_our(35,4) - Delta_V(4,1);
					case 48
						SE_V_our(line+1,4) = SE_V_our(1,4) - Delta_V(4,1);
					case 57
						SE_V_our(line+1,4) = SE_V_our(51,4) - Delta_V(4,1);
					otherwise
						SE_V_our(line+1,4) = SE_V_our(line,4) - Delta_V(4,1);
				end
			end
			
			%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% ERROR %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
			%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% ERROR %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
			%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% ERROR %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
			%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% ERROR %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
			%Krons
			Vm_error_inf_kron = Vm_error_inf_kron + max(max( abs(abs(LF_Ac_V(:,1:err_p))- abs(SE_V_kron(:,1:err_p))) ));
			Vm_error_2_kron = Vm_error_2_kron + sqrt(sum(sum(abs(abs(LF_Ac_V(:,1:err_p))- abs(SE_V_kron(:,1:err_p))).^2))/numel(LF_Ac_V(:,1:err_p)));
            
            Im_error_inf_kron = Im_error_inf_kron + max(max( abs(abs(LF_Ac_I(:,1:err_p))- abs(SE_I_kron(:,1:err_p))) ));
			Im_error_2_kron = Im_error_2_kron + sqrt(sum(sum(abs(abs(LF_Ac_I(:,1:err_p))- abs(SE_I_kron(:,1:err_p))).^2))/numel(LF_Ac_I(:,1:err_p)));
            
			Vang_error_inf_kron = Vang_error_inf_kron + max(max( abs(angle(LF_Ac_V(:,1:err_p))- angle(SE_V_kron(:,1:err_p))) ));
			Vang_error_2_kron = Vang_error_2_kron + sqrt(sum(sum(abs(angle(LF_Ac_V(:,1:err_p))- angle(SE_V_kron(:,1:err_p))).^2))/numel(LF_Ac_V(:,1:err_p)));
            
            Iang_error_inf_kron = Iang_error_inf_kron + max(max( abs(angle(LF_Ac_I(:,1:err_p))- angle(SE_I_kron(:,1:err_p))) ));
			Iang_error_2_kron = Iang_error_2_kron + sqrt(sum(sum(abs(angle(LF_Ac_I(:,1:err_p))- angle(SE_I_kron(:,1:err_p))).^2))/numel(LF_Ac_I(:,1:err_p)));
			
			%Our
			Vm_error_inf_our = Vm_error_inf_our + max(max( abs(abs(LF_Ac_V(:,1:err_p))- abs(SE_V_our(:,1:err_p))) ));
			Vm_error_2_our = Vm_error_2_our + sqrt(sum(sum(abs(abs(LF_Ac_V(:,1:err_p))- abs(SE_V_our(:,1:err_p))).^2))/numel(LF_Ac_V(:,1:err_p)));
            
            Im_error_inf_our = Im_error_inf_our + max(max( abs(abs(LF_Ac_I(:,1:err_p))- abs(SE_I_our(:,1:err_p))) ));
			Im_error_2_our = Im_error_2_our + sqrt(sum(sum(abs(abs(LF_Ac_I(:,1:err_p))- abs(SE_I_our(:,1:err_p))).^2))/numel(LF_Ac_I(:,1:err_p)));
            
			Vang_error_inf_our = Vang_error_inf_our + max(max( abs(angle(LF_Ac_V(:,1:err_p))- angle(SE_V_our(:,1:err_p))) ));
			Vang_error_2_our = Vang_error_2_our + sqrt(sum(sum(abs(angle(LF_Ac_V(:,1:err_p))- angle(SE_V_our(:,1:err_p))).^2))/numel(LF_Ac_V(:,1:err_p)));
            
            Iang_error_inf_our = Iang_error_inf_our + max(max( abs(angle(LF_Ac_I(:,1:err_p))- angle(SE_I_our(:,1:err_p))) ));
			Iang_error_2_our = Iang_error_2_our + sqrt(sum(sum(abs(angle(LF_Ac_I(:,1:err_p))- angle(SE_I_our(:,1:err_p))).^2))/numel(LF_Ac_I(:,1:err_p)));
			
			fprintf('Data Loss case: %d || Loading: %d || MC:%d \n',data_loss_case,Loading,MC);
        end
        %Voltage magnitude errors
		Vm_error_avg_inf_kron(data_loss_case,it,1) = Loading;
		Vm_error_avg_inf_kron(data_loss_case,it,2) = sqrt(Vm_error_inf_kron/MC);
		
		Vm_error_avg_2_kron(data_loss_case,it,1) = Loading;
		Vm_error_avg_2_kron(data_loss_case,it,2) = sqrt(Vm_error_2_kron/MC);
        
        %Current magnitude errors
        Im_error_avg_inf_kron(data_loss_case,it,1) = Loading;
		Im_error_avg_inf_kron(data_loss_case,it,2) = sqrt(Im_error_inf_kron/MC);
		
		Im_error_avg_2_kron(data_loss_case,it,1) = Loading;
		Im_error_avg_2_kron(data_loss_case,it,2) = sqrt(Im_error_2_kron/MC);
        
        %Voltage angle errors
        Vang_error_avg_inf_kron(data_loss_case,it,1) = Loading;
		Vang_error_avg_inf_kron(data_loss_case,it,2) = sqrt(Vang_error_inf_kron/MC);
		
		Vang_error_avg_2_kron(data_loss_case,it,1) = Loading;
		Vang_error_avg_2_kron(data_loss_case,it,2) = sqrt(Vang_error_2_kron/MC);
        
        %Current angle errors
        Iang_error_avg_inf_kron(data_loss_case,it,1) = Loading;
		Iang_error_avg_inf_kron(data_loss_case,it,2) = sqrt(Iang_error_inf_kron/MC);
		
		Iang_error_avg_2_kron(data_loss_case,it,1) = Loading;
		Iang_error_avg_2_kron(data_loss_case,it,2) = sqrt(Iang_error_2_kron/MC);
		
		%Our method
		%Voltage magnitude errors
		Vm_error_avg_inf_our(data_loss_case,it,1) = Loading;
		Vm_error_avg_inf_our(data_loss_case,it,2) = sqrt(Vm_error_inf_our/MC);
		
		Vm_error_avg_2_our(data_loss_case,it,1) = Loading;
		Vm_error_avg_2_our(data_loss_case,it,2) = sqrt(Vm_error_2_our/MC);
        
        %Current magnitude errors
        Im_error_avg_inf_our(data_loss_case,it,1) = Loading;
		Im_error_avg_inf_our(data_loss_case,it,2) = sqrt(Im_error_inf_our/MC);
		
		Im_error_avg_2_our(data_loss_case,it,1) = Loading;
		Im_error_avg_2_our(data_loss_case,it,2) = sqrt(Im_error_2_our/MC);
        
        %Voltage angle errors
        Vang_error_avg_inf_our(data_loss_case,it,1) = Loading;
		Vang_error_avg_inf_our(data_loss_case,it,2) = sqrt(Vang_error_inf_our/MC);
		
		Vang_error_avg_2_our(data_loss_case,it,1) = Loading;
		Vang_error_avg_2_our(data_loss_case,it,2) = sqrt(Vang_error_2_our/MC);
        
        %Current angle errors
        Iang_error_avg_inf_our(data_loss_case,it,1) = Loading;
		Iang_error_avg_inf_our(data_loss_case,it,2) = sqrt(Iang_error_inf_our/MC);
		
		Iang_error_avg_2_our(data_loss_case,it,1) = Loading;
		Iang_error_avg_2_our(data_loss_case,it,2) = sqrt(Iang_error_2_our/MC);
		
		it = it+1;
		end	
		it=1;
end

%Voltage magnitude errors - 
%Average Maximum Voltage Magnitude Error - AMVME
Fig1 = figure('Renderer', 'painters', 'Position', [10 10 700 800]);
hold on;
grid on;
plot(squeeze(Vm_error_avg_inf_kron(1,:,1)),squeeze(Vm_error_avg_inf_kron(1,:,2)),'ro-','Linewidth',1.5);
plot(squeeze(Vm_error_avg_inf_kron(2,:,1)),squeeze(Vm_error_avg_inf_kron(2,:,2)),'bo-','Linewidth',1.5);
plot(squeeze(Vm_error_avg_inf_kron(3,:,1)),squeeze(Vm_error_avg_inf_kron(3,:,2)),'go-','Linewidth',1.5);
plot(squeeze(Vm_error_avg_inf_kron(4,:,1)),squeeze(Vm_error_avg_inf_kron(4,:,2)),'ko-','Linewidth',1.5);
plot(squeeze(Vm_error_avg_inf_kron(5,:,1)),squeeze(Vm_error_avg_inf_kron(5,:,2)),'mo-','Linewidth',1.5);
plot(squeeze(Vm_error_avg_inf_kron(6,:,1)),squeeze(Vm_error_avg_inf_kron(6,:,2)),'co-','Linewidth',1.5);

plot(squeeze(Vm_error_avg_inf_our(1,:,1)),squeeze(Vm_error_avg_inf_our(1,:,2)),'--r*','Linewidth',1.5);
plot(squeeze(Vm_error_avg_inf_our(2,:,1)),squeeze(Vm_error_avg_inf_our(2,:,2)),'--b*','Linewidth',1.5);
plot(squeeze(Vm_error_avg_inf_our(3,:,1)),squeeze(Vm_error_avg_inf_our(3,:,2)),'--g*','Linewidth',1.5);
plot(squeeze(Vm_error_avg_inf_our(4,:,1)),squeeze(Vm_error_avg_inf_our(4,:,2)),'--k*','Linewidth',1.5);
plot(squeeze(Vm_error_avg_inf_our(5,:,1)),squeeze(Vm_error_avg_inf_our(5,:,2)),'--m*','Linewidth',1.5);
plot(squeeze(Vm_error_avg_inf_our(6,:,1)),squeeze(Vm_error_avg_inf_our(6,:,2)),'--c*','Linewidth',1.5); 
legend({'Data loss = 0\% using $\mathbf{Y^{abc}}$','Data loss = 5\% using $\mathbf{Y^{abc}}$', 'Data loss = 10\% using $\mathbf{Y^{abc}}$','Data loss = 15\% using $\mathbf{Y^{abc}}$', 'Data loss = 20\% using $\mathbf{Y^{abc}}$','Data loss = 25\% using $\mathbf{Y^{abc}}$', 'Data loss = 0\% using $\mathbf{\overline{Y}^{abc}}$', 'Data loss = 5\% using $\mathbf{\overline{Y}^{abc}}$', 'Data loss = 10\% using $\mathbf{\overline{Y}^{abc}}$','Data loss = 15\% using $\mathbf{\overline{Y}^{abc}}$','Data loss = 20\% using $\mathbf{\overline{Y}^{abc}}$', 'Data loss = 25\% using $\mathbf{\overline{Y}^{abc}}$'},'Location','NorthWest','Interpreter','latex','FontSize',11);
xlabel('Transformer Loading','FontSize',13);
ylabel('$\mathbf{|\Delta |V| |_{avg}^{\infty}/ (V)}$','Interpreter','latex','FontSize',13);
title('Average Maximum Voltage Magniture Error (AMVME)');


%Voltage magnitude errors - 
%Average Voltage Magnitude Error - AVME
Fig2 = figure('Renderer', 'painters', 'Position', [10 10 700 800]);
hold on;
grid on;
plot(squeeze(Vm_error_avg_2_kron(1,:,1)),squeeze(Vm_error_avg_2_kron(1,:,2)),'ro-','Linewidth',1.5);
plot(squeeze(Vm_error_avg_2_kron(2,:,1)),squeeze(Vm_error_avg_2_kron(2,:,2)),'bo-','Linewidth',1.5);
plot(squeeze(Vm_error_avg_2_kron(3,:,1)),squeeze(Vm_error_avg_2_kron(3,:,2)),'go-','Linewidth',1.5);
plot(squeeze(Vm_error_avg_2_kron(4,:,1)),squeeze(Vm_error_avg_2_kron(4,:,2)),'ko-','Linewidth',1.5);
plot(squeeze(Vm_error_avg_2_kron(5,:,1)),squeeze(Vm_error_avg_2_kron(5,:,2)),'mo-','Linewidth',1.5);
plot(squeeze(Vm_error_avg_2_kron(6,:,1)),squeeze(Vm_error_avg_2_kron(6,:,2)),'co-','Linewidth',1.5);

plot(squeeze(Vm_error_avg_2_our(1,:,1)),squeeze(Vm_error_avg_2_our(1,:,2)),'--r*','Linewidth',1.5);
plot(squeeze(Vm_error_avg_2_our(2,:,1)),squeeze(Vm_error_avg_2_our(2,:,2)),'--b*','Linewidth',1.5);
plot(squeeze(Vm_error_avg_2_our(3,:,1)),squeeze(Vm_error_avg_2_our(3,:,2)),'--g*','Linewidth',1.5);
plot(squeeze(Vm_error_avg_2_our(4,:,1)),squeeze(Vm_error_avg_2_our(4,:,2)),'--k*','Linewidth',1.5);
plot(squeeze(Vm_error_avg_2_our(5,:,1)),squeeze(Vm_error_avg_2_our(5,:,2)),'--m*','Linewidth',1.5);
plot(squeeze(Vm_error_avg_2_our(6,:,1)),squeeze(Vm_error_avg_2_our(6,:,2)),'--c*','Linewidth',1.5);
xlabel('Transformer Loading');
ylabel('$\mathbf{|\Delta |V| |_{avg}^{2}/ (V)}$','Interpreter','latex','FontSize',13);
legend({'Data loss = 0\% using $\mathbf{Y^{abc}}$','Data loss = 5\% using $\mathbf{Y^{abc}}$', 'Data loss = 10\% using $\mathbf{Y^{abc}}$','Data loss = 15\% using $\mathbf{Y^{abc}}$', 'Data loss = 20\% using $\mathbf{Y^{abc}}$','Data loss = 25\% using $\mathbf{Y^{abc}}$', 'Data loss = 0\% using $\mathbf{\overline{Y}^{abc}}$', 'Data loss = 5\% using $\mathbf{\overline{Y}^{abc}}$', 'Data loss = 10\% using $\mathbf{\overline{Y}^{abc}}$','Data loss = 15\% using $\mathbf{\overline{Y}^{abc}}$','Data loss = 20\% using $\mathbf{\overline{Y}^{abc}}$', 'Data loss = 25\% using $\mathbf{\overline{Y}^{abc}}$'},'Location','NorthWest','Interpreter','latex','FontSize',11);
title('Average Voltage Magniture Error (AVME)');

%Current magnitude errors - 
%Average Maximum Current Magnitude Error - AMCME
Fig3 = figure('Renderer', 'painters', 'Position', [10 10 700 800]);
hold on;
grid on;
plot(squeeze(Im_error_avg_inf_kron(1,:,1)),squeeze(Im_error_avg_inf_kron(1,:,2)),'ro-','Linewidth',1.5);
plot(squeeze(Im_error_avg_inf_kron(2,:,1)),squeeze(Im_error_avg_inf_kron(2,:,2)),'bo-','Linewidth',1.5);
plot(squeeze(Im_error_avg_inf_kron(3,:,1)),squeeze(Im_error_avg_inf_kron(3,:,2)),'go-','Linewidth',1.5);
plot(squeeze(Im_error_avg_inf_kron(4,:,1)),squeeze(Im_error_avg_inf_kron(4,:,2)),'ko-','Linewidth',1.5);
plot(squeeze(Im_error_avg_inf_kron(5,:,1)),squeeze(Im_error_avg_inf_kron(5,:,2)),'mo-','Linewidth',1.5);
plot(squeeze(Im_error_avg_inf_kron(6,:,1)),squeeze(Im_error_avg_inf_kron(6,:,2)),'co-','Linewidth',1.5);

plot(squeeze(Im_error_avg_inf_our(1,:,1)),squeeze(Im_error_avg_inf_our(1,:,2)),'--r*','Linewidth',1.5);
plot(squeeze(Im_error_avg_inf_our(2,:,1)),squeeze(Im_error_avg_inf_our(2,:,2)),'--b*','Linewidth',1.5);
plot(squeeze(Im_error_avg_inf_our(3,:,1)),squeeze(Im_error_avg_inf_our(3,:,2)),'--g*','Linewidth',1.5);
plot(squeeze(Im_error_avg_inf_our(4,:,1)),squeeze(Im_error_avg_inf_our(4,:,2)),'--k*','Linewidth',1.5);
plot(squeeze(Im_error_avg_inf_our(5,:,1)),squeeze(Im_error_avg_inf_our(5,:,2)),'--m*','Linewidth',1.5);
plot(squeeze(Im_error_avg_inf_our(6,:,1)),squeeze(Im_error_avg_inf_our(6,:,2)),'--c*','Linewidth',1.5);
legend({'Data loss = 0\% using $\mathbf{Y^{abc}}$','Data loss = 5\% using $\mathbf{Y^{abc}}$', 'Data loss = 10\% using $\mathbf{Y^{abc}}$','Data loss = 15\% using $\mathbf{Y^{abc}}$', 'Data loss = 20\% using $\mathbf{Y^{abc}}$','Data loss = 25\% using $\mathbf{Y^{abc}}$', 'Data loss = 0\% using $\mathbf{\overline{Y}^{abc}}$', 'Data loss = 5\% using $\mathbf{\overline{Y}^{abc}}$', 'Data loss = 10\% using $\mathbf{\overline{Y}^{abc}}$','Data loss = 15\% using $\mathbf{\overline{Y}^{abc}}$','Data loss = 20\% using $\mathbf{\overline{Y}^{abc}}$', 'Data loss = 25\% using $\mathbf{\overline{Y}^{abc}}$'},'Location','NorthWest','Interpreter','latex','FontSize',11);
xlabel('Transformer Loading');
ylabel('$\mathbf{|\Delta |I| |_{avg}^{\infty}/ (A)}$','Interpreter','latex','FontSize',13);
title('Average Maximum Current Magnitude Error (AMCME)');


%Current magnitude errors - 
%Average Current Magnitude Error - ACME
Fig4 = figure('Renderer', 'painters', 'Position', [10 10 700 800]);
hold on;
grid on;
plot(squeeze(Im_error_avg_2_kron(1,:,1)),squeeze(Im_error_avg_2_kron(1,:,2)),'ro-','Linewidth',1.5);
plot(squeeze(Im_error_avg_2_kron(2,:,1)),squeeze(Im_error_avg_2_kron(2,:,2)),'bo-','Linewidth',1.5);
plot(squeeze(Im_error_avg_2_kron(3,:,1)),squeeze(Im_error_avg_2_kron(3,:,2)),'go-','Linewidth',1.5);
plot(squeeze(Im_error_avg_2_kron(4,:,1)),squeeze(Im_error_avg_2_kron(4,:,2)),'ko-','Linewidth',1.5);
plot(squeeze(Im_error_avg_2_kron(5,:,1)),squeeze(Im_error_avg_2_kron(5,:,2)),'mo-','Linewidth',1.5);
plot(squeeze(Im_error_avg_2_kron(6,:,1)),squeeze(Im_error_avg_2_kron(6,:,2)),'co-','Linewidth',1.5);

plot(squeeze(Im_error_avg_2_our(1,:,1)),squeeze(Im_error_avg_2_our(1,:,2)),'--r*','Linewidth',1.5);
plot(squeeze(Im_error_avg_2_our(2,:,1)),squeeze(Im_error_avg_2_our(2,:,2)),'--b*','Linewidth',1.5);
plot(squeeze(Im_error_avg_2_our(3,:,1)),squeeze(Im_error_avg_2_our(3,:,2)),'--g*','Linewidth',1.5);
plot(squeeze(Im_error_avg_2_our(4,:,1)),squeeze(Im_error_avg_2_our(4,:,2)),'--k*','Linewidth',1.5);
plot(squeeze(Im_error_avg_2_our(5,:,1)),squeeze(Im_error_avg_2_our(5,:,2)),'--m*','Linewidth',1.5);
plot(squeeze(Im_error_avg_2_our(6,:,1)),squeeze(Im_error_avg_2_our(6,:,2)),'--c*','Linewidth',1.5);
xlabel('Transformer Loading');
ylabel('$\mathbf{|\Delta |I| |_{avg}^{2}/ (A)}$','Interpreter','latex','FontSize',13);
legend({'Data loss = 0\% using $\mathbf{Y^{abc}}$','Data loss = 5\% using $\mathbf{Y^{abc}}$', 'Data loss = 10\% using $\mathbf{Y^{abc}}$','Data loss = 15\% using $\mathbf{Y^{abc}}$', 'Data loss = 20\% using $\mathbf{Y^{abc}}$','Data loss = 25\% using $\mathbf{Y^{abc}}$', 'Data loss = 0\% using $\mathbf{\overline{Y}^{abc}}$', 'Data loss = 5\% using $\mathbf{\overline{Y}^{abc}}$', 'Data loss = 10\% using $\mathbf{\overline{Y}^{abc}}$','Data loss = 15\% using $\mathbf{\overline{Y}^{abc}}$','Data loss = 20\% using $\mathbf{\overline{Y}^{abc}}$', 'Data loss = 25\% using $\mathbf{\overline{Y}^{abc}}$'},'Location','NorthWest','Interpreter','latex','FontSize',11);
title('Average Current Magnitude Error (ACME)');

%Voltage angle errors - 
%Average Maximum Voltage Angle Error - AMVAE
Fig5 = figure('Renderer', 'painters', 'Position', [10 10 700 800]);
hold on;
grid on;
plot(squeeze(Vang_error_avg_inf_kron(1,:,1)),squeeze(Vang_error_avg_inf_kron(1,:,2)),'ro-','Linewidth',1.5);
plot(squeeze(Vang_error_avg_inf_kron(2,:,1)),squeeze(Vang_error_avg_inf_kron(2,:,2)),'bo-','Linewidth',1.5);
plot(squeeze(Vang_error_avg_inf_kron(3,:,1)),squeeze(Vang_error_avg_inf_kron(3,:,2)),'go-','Linewidth',1.5);
plot(squeeze(Vang_error_avg_inf_kron(4,:,1)),squeeze(Vang_error_avg_inf_kron(4,:,2)),'ko-','Linewidth',1.5);
plot(squeeze(Vang_error_avg_inf_kron(5,:,1)),squeeze(Vang_error_avg_inf_kron(5,:,2)),'mo-','Linewidth',1.5);
plot(squeeze(Vang_error_avg_inf_kron(6,:,1)),squeeze(Vang_error_avg_inf_kron(6,:,2)),'co-','Linewidth',1.5);

plot(squeeze(Vang_error_avg_inf_our(1,:,1)),squeeze(Vang_error_avg_inf_our(1,:,2)),'--r*','Linewidth',1.5);
plot(squeeze(Vang_error_avg_inf_our(2,:,1)),squeeze(Vang_error_avg_inf_our(2,:,2)),'--b*','Linewidth',1.5);
plot(squeeze(Vang_error_avg_inf_our(3,:,1)),squeeze(Vang_error_avg_inf_our(3,:,2)),'--g*','Linewidth',1.5);
plot(squeeze(Vang_error_avg_inf_our(4,:,1)),squeeze(Vang_error_avg_inf_our(4,:,2)),'--k*','Linewidth',1.5);
plot(squeeze(Vang_error_avg_inf_our(5,:,1)),squeeze(Vang_error_avg_inf_our(5,:,2)),'--m*','Linewidth',1.5);
plot(squeeze(Vang_error_avg_inf_our(6,:,1)),squeeze(Vang_error_avg_inf_our(6,:,2)),'--c*','Linewidth',1.5);
legend({'Data loss = 0\% using $\mathbf{Y^{abc}}$','Data loss = 5\% using $\mathbf{Y^{abc}}$', 'Data loss = 10\% using $\mathbf{Y^{abc}}$','Data loss = 15\% using $\mathbf{Y^{abc}}$', 'Data loss = 20\% using $\mathbf{Y^{abc}}$','Data loss = 25\% using $\mathbf{Y^{abc}}$', 'Data loss = 0\% using $\mathbf{\overline{Y}^{abc}}$', 'Data loss = 5\% using $\mathbf{\overline{Y}^{abc}}$', 'Data loss = 10\% using $\mathbf{\overline{Y}^{abc}}$','Data loss = 15\% using $\mathbf{\overline{Y}^{abc}}$','Data loss = 20\% using $\mathbf{\overline{Y}^{abc}}$', 'Data loss = 25\% using $\mathbf{\overline{Y}^{abc}}$'},'Location','NorthWest','Interpreter','latex','FontSize',11);
xlabel('Transformer Loading');
ylabel('$\mathbf{|\Delta V_{\theta} |_{avg}^{\infty}/ (A)}$','Interpreter','latex','FontSize',13);
title('Average Maximum Voltage Angle Error (AMVAE)');


%Voltage angle errors - 
%Average Voltage Angle Error - AVAE
Fig6 = figure('Renderer', 'painters', 'Position', [10 10 700 800]);
hold on;
grid on;
plot(squeeze(Vang_error_avg_2_kron(1,:,1)),squeeze(Vang_error_avg_2_kron(1,:,2)),'ro-','Linewidth',1.5);
plot(squeeze(Vang_error_avg_2_kron(2,:,1)),squeeze(Vang_error_avg_2_kron(2,:,2)),'bo-','Linewidth',1.5);
plot(squeeze(Vang_error_avg_2_kron(3,:,1)),squeeze(Vang_error_avg_2_kron(3,:,2)),'go-','Linewidth',1.5);
plot(squeeze(Vang_error_avg_2_kron(4,:,1)),squeeze(Vang_error_avg_2_kron(4,:,2)),'ko-','Linewidth',1.5);
plot(squeeze(Vang_error_avg_2_kron(5,:,1)),squeeze(Vang_error_avg_2_kron(5,:,2)),'mo-','Linewidth',1.5);
plot(squeeze(Vang_error_avg_2_kron(6,:,1)),squeeze(Vang_error_avg_2_kron(6,:,2)),'co-','Linewidth',1.5);

plot(squeeze(Vang_error_avg_2_our(1,:,1)),squeeze(Vang_error_avg_2_our(1,:,2)),'--r*','Linewidth',1.5);
plot(squeeze(Vang_error_avg_2_our(2,:,1)),squeeze(Vang_error_avg_2_our(2,:,2)),'--b*','Linewidth',1.5);
plot(squeeze(Vang_error_avg_2_our(3,:,1)),squeeze(Vang_error_avg_2_our(3,:,2)),'--g*','Linewidth',1.5);
plot(squeeze(Vang_error_avg_2_our(4,:,1)),squeeze(Vang_error_avg_2_our(4,:,2)),'--k*','Linewidth',1.5);
plot(squeeze(Vang_error_avg_2_our(5,:,1)),squeeze(Vang_error_avg_2_our(5,:,2)),'--m*','Linewidth',1.5);
plot(squeeze(Vang_error_avg_2_our(6,:,1)),squeeze(Vang_error_avg_2_our(6,:,2)),'--c*','Linewidth',1.5);
xlabel('Transformer Loading');
ylabel('$\mathbf{||\Delta V_{\theta} ||_{avg}^{2}/ (radians)}$','Interpreter','latex','FontSize',13);
legend({'Data loss = 0\% using $\mathbf{Y^{abc}}$','Data loss = 5\% using $\mathbf{Y^{abc}}$', 'Data loss = 10\% using $\mathbf{Y^{abc}}$','Data loss = 15\% using $\mathbf{Y^{abc}}$', 'Data loss = 20\% using $\mathbf{Y^{abc}}$','Data loss = 25\% using $\mathbf{Y^{abc}}$', 'Data loss = 0\% using $\mathbf{\overline{Y}^{abc}}$', 'Data loss = 5\% using $\mathbf{\overline{Y}^{abc}}$', 'Data loss = 10\% using $\mathbf{\overline{Y}^{abc}}$','Data loss = 15\% using $\mathbf{\overline{Y}^{abc}}$','Data loss = 20\% using $\mathbf{\overline{Y}^{abc}}$', 'Data loss = 25\% using $\mathbf{\overline{Y}^{abc}}$'},'Location','NorthWest','Interpreter','latex','FontSize',11);
title('Average Voltage Angle Error (AVAE)');

%Current Angle errors - 
%Average Maximum Current Angle Error - AMCAE
Fig7 = figure('Renderer', 'painters', 'Position', [10 10 700 800]);
hold on;
grid on;
plot(squeeze(Iang_error_avg_inf_kron(1,:,1)),squeeze(Iang_error_avg_inf_kron(1,:,2)),'ro-','Linewidth',1.5);
plot(squeeze(Iang_error_avg_inf_kron(2,:,1)),squeeze(Iang_error_avg_inf_kron(2,:,2)),'bo-','Linewidth',1.5);
plot(squeeze(Iang_error_avg_inf_kron(3,:,1)),squeeze(Iang_error_avg_inf_kron(3,:,2)),'go-','Linewidth',1.5);
plot(squeeze(Iang_error_avg_inf_kron(4,:,1)),squeeze(Iang_error_avg_inf_kron(4,:,2)),'ko-','Linewidth',1.5);
plot(squeeze(Iang_error_avg_inf_kron(5,:,1)),squeeze(Iang_error_avg_inf_kron(5,:,2)),'mo-','Linewidth',1.5);
plot(squeeze(Iang_error_avg_inf_kron(6,:,1)),squeeze(Iang_error_avg_inf_kron(6,:,2)),'co-','Linewidth',1.5);

plot(squeeze(Iang_error_avg_inf_our(1,:,1)),squeeze(Iang_error_avg_inf_our(1,:,2)),'--r*','Linewidth',1.5);
plot(squeeze(Iang_error_avg_inf_our(2,:,1)),squeeze(Iang_error_avg_inf_our(2,:,2)),'--b*','Linewidth',1.5);
plot(squeeze(Iang_error_avg_inf_our(3,:,1)),squeeze(Iang_error_avg_inf_our(3,:,2)),'--g*','Linewidth',1.5);
plot(squeeze(Iang_error_avg_inf_our(4,:,1)),squeeze(Iang_error_avg_inf_our(4,:,2)),'--k*','Linewidth',1.5);
plot(squeeze(Iang_error_avg_inf_our(5,:,1)),squeeze(Iang_error_avg_inf_our(5,:,2)),'--m*','Linewidth',1.5);
plot(squeeze(Iang_error_avg_inf_our(6,:,1)),squeeze(Iang_error_avg_inf_our(6,:,2)),'--c*','Linewidth',1.5);
legend({'Data loss = 0\% using $\mathbf{Y^{abc}}$','Data loss = 5\% using $\mathbf{Y^{abc}}$', 'Data loss = 10\% using $\mathbf{Y^{abc}}$','Data loss = 15\% using $\mathbf{Y^{abc}}$', 'Data loss = 20\% using $\mathbf{Y^{abc}}$','Data loss = 25\% using $\mathbf{Y^{abc}}$', 'Data loss = 0\% using $\mathbf{\overline{Y}^{abc}}$', 'Data loss = 5\% using $\mathbf{\overline{Y}^{abc}}$', 'Data loss = 10\% using $\mathbf{\overline{Y}^{abc}}$','Data loss = 15\% using $\mathbf{\overline{Y}^{abc}}$','Data loss = 20\% using $\mathbf{\overline{Y}^{abc}}$', 'Data loss = 25\% using $\mathbf{\overline{Y}^{abc}}$'},'Location','NorthWest','Interpreter','latex','FontSize',11);
xlabel('Transformer Loading');
ylabel('$\mathbf{|\Delta I_{\theta} |_{avg}^{\infty}/ (radians)}$','Interpreter','latex','FontSize',13);
title('Average Maximum Current Angle Error (AMCAE)');


%Current magnitude errors - 
%Average Current Angle Error - ACAE
Fig8 = figure('Renderer', 'painters', 'Position', [10 10 700 800]);
hold on;
grid on;
plot(squeeze(Iang_error_avg_2_kron(1,:,1)),squeeze(Iang_error_avg_2_kron(1,:,2)),'ro-','Linewidth',1.5);
plot(squeeze(Iang_error_avg_2_kron(2,:,1)),squeeze(Iang_error_avg_2_kron(2,:,2)),'bo-','Linewidth',1.5);
plot(squeeze(Iang_error_avg_2_kron(3,:,1)),squeeze(Iang_error_avg_2_kron(3,:,2)),'go-','Linewidth',1.5);
plot(squeeze(Iang_error_avg_2_kron(4,:,1)),squeeze(Iang_error_avg_2_kron(4,:,2)),'ko-','Linewidth',1.5);
plot(squeeze(Iang_error_avg_2_kron(5,:,1)),squeeze(Iang_error_avg_2_kron(5,:,2)),'mo-','Linewidth',1.5);
plot(squeeze(Iang_error_avg_2_kron(6,:,1)),squeeze(Iang_error_avg_2_kron(6,:,2)),'co-','Linewidth',1.5);

plot(squeeze(Iang_error_avg_2_our(1,:,1)),squeeze(Iang_error_avg_2_our(1,:,2)),'--r*','Linewidth',1.5);
plot(squeeze(Iang_error_avg_2_our(2,:,1)),squeeze(Iang_error_avg_2_our(2,:,2)),'--b*','Linewidth',1.5);
plot(squeeze(Iang_error_avg_2_our(3,:,1)),squeeze(Iang_error_avg_2_our(3,:,2)),'--g*','Linewidth',1.5);
plot(squeeze(Iang_error_avg_2_our(4,:,1)),squeeze(Iang_error_avg_2_our(4,:,2)),'--k*','Linewidth',1.5);
plot(squeeze(Iang_error_avg_2_our(5,:,1)),squeeze(Iang_error_avg_2_our(5,:,2)),'--m*','Linewidth',1.5);
plot(squeeze(Iang_error_avg_2_our(6,:,1)),squeeze(Iang_error_avg_2_our(6,:,2)),'--c*','Linewidth',1.5);
xlabel('Transformer Loading');
ylabel('$\mathbf{|\Delta I_{\theta} |_{avg}^{2}/ (radians)}$','Interpreter','latex','FontSize',13);
legend({'Data loss = 0\% using $\mathbf{Y^{abc}}$','Data loss = 5\% using $\mathbf{Y^{abc}}$', 'Data loss = 10\% using $\mathbf{Y^{abc}}$','Data loss = 15\% using $\mathbf{Y^{abc}}$', 'Data loss = 20\% using $\mathbf{Y^{abc}}$','Data loss = 25\% using $\mathbf{Y^{abc}}$', 'Data loss = 0\% using $\mathbf{\overline{Y}^{abc}}$', 'Data loss = 5\% using $\mathbf{\overline{Y}^{abc}}$', 'Data loss = 10\% using $\mathbf{\overline{Y}^{abc}}$','Data loss = 15\% using $\mathbf{\overline{Y}^{abc}}$','Data loss = 20\% using $\mathbf{\overline{Y}^{abc}}$', 'Data loss = 25\% using $\mathbf{\overline{Y}^{abc}}$'},'Location','NorthWest','Interpreter','latex','FontSize',11);
title('Average Current Angle Error (ACAE)');

print(Fig1,'E:\Chaminda\7.State_Estimation_LotusGrove\V3_with_new_Krons\Error_with_loss\With_Comparision\Results\AMVME_Loss.png','-dpng','-r400');
print(Fig2,'E:\Chaminda\7.State_Estimation_LotusGrove\V3_with_new_Krons\Error_with_loss\With_Comparision\Results\AVME_Loss.png','-dpng','-r400');
print(Fig3,'E:\Chaminda\7.State_Estimation_LotusGrove\V3_with_new_Krons\Error_with_loss\With_Comparision\Results\AMCME_Loss.png','-dpng','-r400');
print(Fig4,'E:\Chaminda\7.State_Estimation_LotusGrove\V3_with_new_Krons\Error_with_loss\With_Comparision\Results\ACME_Loss.png','-dpng','-r400');
print(Fig5,'E:\Chaminda\7.State_Estimation_LotusGrove\V3_with_new_Krons\Error_with_loss\With_Comparision\Results\AMVAE_Loss.png','-dpng','-r400');
print(Fig6,'E:\Chaminda\7.State_Estimation_LotusGrove\V3_with_new_Krons\Error_with_loss\With_Comparision\Results\AVAE_Loss.png','-dpng','-r400');
print(Fig7,'E:\Chaminda\7.State_Estimation_LotusGrove\V3_with_new_Krons\Error_with_loss\With_Comparision\Results\AMCAE_Loss.png','-dpng','-r400');
print(Fig8,'E:\Chaminda\7.State_Estimation_LotusGrove\V3_with_new_Krons\Error_with_loss\With_Comparision\Results\ACAE_Loss.png','-dpng','-r400');
