close all;
clear all;
clc;

Table_loss = zeros(24,3);
A = load('LOSS_AMVME.mat');
B = load('LOSS_AVME.mat');
C = load('LOSS_AMCME.mat');
D = load('LOSS_ACME.mat');

A = squeeze(A.LOSS_AMVME);
B = squeeze(B.LOSS_AVME);
C = squeeze(C.LOSS_AMCME);
D = squeeze(D.LOSS_ACME);

for i=2:7
    Table_loss((i-2)*4+1,1)=A(19,i);
    Table_loss((i-2)*4+2,1)=B(19,i);
    Table_loss((i-2)*4+3,1)=C(19,i);
    Table_loss((i-2)*4+4,1)=D(19,i);
end

for i=8:13
    Table_loss((i-8)*4+1,2)=A(19,i);
    Table_loss((i-8)*4+2,2)=B(19,i);
    Table_loss((i-8)*4+3,2)=C(19,i);
    Table_loss((i-8)*4+4,2)=D(19,i);
end

Table_loss(:,3) = 100.*((Table_loss(:,1)-Table_loss(:,2))./Table_loss(:,1));