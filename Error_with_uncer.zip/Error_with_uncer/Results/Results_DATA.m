clear all;
close all;
clc;

load('when_4_phase_used.mat')

%AVERAGE MAXIMUM VOLTAGE MAGNITUDE ERROR
%C1 = Transformer loading
%C2 = 

%% AMVME
UNCER_AMVME(:,1) = squeeze(Vm_error_avg_inf_kron(1,:,1))';   %X
UNCER_AMVME(:,2) = squeeze(Vm_error_avg_inf_kron(1,:,2))';   %0
UNCER_AMVME(:,3) = squeeze(Vm_error_avg_inf_kron(2,:,2))';   %5
UNCER_AMVME(:,4) = squeeze(Vm_error_avg_inf_kron(3,:,2))';   %10
UNCER_AMVME(:,5) = squeeze(Vm_error_avg_inf_kron(4,:,2))';   %15

UNCER_AMVME(:,6) = squeeze(Vm_error_avg_inf_our(1,:,2))';    %0
UNCER_AMVME(:,7) = squeeze(Vm_error_avg_inf_our(2,:,2))';    %5
UNCER_AMVME(:,8) = squeeze(Vm_error_avg_inf_our(3,:,2))';    %10
UNCER_AMVME(:,9) = squeeze(Vm_error_avg_inf_our(4,:,2))';    %15

save('E:\Chaminda\7.State_Estimation_LotusGrove\V3_with_new_Krons\Error_with_uncer\With_Comparision\Results\UNCER_AMVME.csv', 'UNCER_AMVME', '-ASCII','-append');

%% AVME
UNCER_AVME(:,1) = squeeze(Vm_error_avg_2_kron(1,:,1))';   %TRANSFORMER LOADING
UNCER_AVME(:,2) = squeeze(Vm_error_avg_2_kron(1,:,2))';   % 0.5l
UNCER_AVME(:,3) = squeeze(Vm_error_avg_2_kron(2,:,2))';   % 1l
UNCER_AVME(:,4) = squeeze(Vm_error_avg_2_kron(3,:,2))';   % 1.5l
UNCER_AVME(:,5) = squeeze(Vm_error_avg_2_kron(4,:,2))';   % 1.5l

UNCER_AVME(:,6) = squeeze(Vm_error_avg_2_our(1,:,2))';    % 0.5L
UNCER_AVME(:,7) = squeeze(Vm_error_avg_2_our(2,:,2))';    % 1L
UNCER_AVME(:,8) = squeeze(Vm_error_avg_2_our(3,:,2))';    % 1.5L
UNCER_AVME(:,9) = squeeze(Vm_error_avg_2_our(4,:,2))';    % 1.5L

save('E:\Chaminda\7.State_Estimation_LotusGrove\V3_with_new_Krons\Error_with_uncer\With_Comparision\Results\UNCER_AVME.csv', 'UNCER_AVME', '-ASCII','-append');

%% AMCME
UNCER_AMCME(:,1) = squeeze(Im_error_avg_inf_kron(1,:,1))';   %TRANSFORMER LOADING
UNCER_AMCME(:,2) = squeeze(Im_error_avg_inf_kron(1,:,2))';   % 0.5l
UNCER_AMCME(:,3) = squeeze(Im_error_avg_inf_kron(2,:,2))';   % 1l
UNCER_AMCME(:,4) = squeeze(Im_error_avg_inf_kron(3,:,2))';   % 1.5l
UNCER_AMCME(:,5) = squeeze(Im_error_avg_inf_kron(4,:,2))';   % 1.5l


UNCER_AMCME(:,6) = squeeze(Im_error_avg_inf_our(1,:,2))';    % 0.5L
UNCER_AMCME(:,7) = squeeze(Im_error_avg_inf_our(2,:,2))';    % 1L
UNCER_AMCME(:,8) = squeeze(Im_error_avg_inf_our(3,:,2))';    % 1.5L
UNCER_AMCME(:,9) = squeeze(Im_error_avg_inf_our(4,:,2))';    % 1.5L
save('E:\Chaminda\7.State_Estimation_LotusGrove\V3_with_new_Krons\Error_with_uncer\With_Comparision\Results\UNCER_AMCME.csv', 'UNCER_AMCME', '-ASCII','-append');


%% ACME
UNCER_ACME(:,1) = squeeze(Im_error_avg_2_kron(1,:,1))';   %TRANSFORMER LOADING
UNCER_ACME(:,2) = squeeze(Im_error_avg_2_kron(1,:,2))';   % 0.5l
UNCER_ACME(:,3) = squeeze(Im_error_avg_2_kron(2,:,2))';   % 1l
UNCER_ACME(:,4) = squeeze(Im_error_avg_2_kron(3,:,2))';   % 1.5l
UNCER_ACME(:,5) = squeeze(Im_error_avg_2_kron(4,:,2))';   % 1.5l

UNCER_ACME(:,6) = squeeze(Im_error_avg_2_our(1,:,2))';    % 0.5L
UNCER_ACME(:,7) = squeeze(Im_error_avg_2_our(2,:,2))';    % 1L
UNCER_ACME(:,8) = squeeze(Im_error_avg_2_our(3,:,2))';    % 1.5L
UNCER_ACME(:,9) = squeeze(Im_error_avg_2_our(4,:,2))';    % 1.5L
save('E:\Chaminda\7.State_Estimation_LotusGrove\V3_with_new_Krons\Error_with_uncer\With_Comparision\Results\UNCER_ACME.csv', 'UNCER_ACME', '-ASCII','-append');
