clear all;
close all;
clc;

load('Results_Workspace.mat');

%AVERAGE MAXIMUM VOLTAGE MAGNITUDE ERROR
%C1 = Transformer loading
%C2 = 

%% AMVME
LOSS_AMVME(:,1) = squeeze(Vm_error_avg_inf_kron(1,:,1))';   %X
LOSS_AMVME(:,2) = squeeze(Vm_error_avg_inf_kron(1,:,2))';   %0
LOSS_AMVME(:,3) = squeeze(Vm_error_avg_inf_kron(2,:,2))';   %5
LOSS_AMVME(:,4) = squeeze(Vm_error_avg_inf_kron(3,:,2))';   %10
LOSS_AMVME(:,5) = squeeze(Vm_error_avg_inf_kron(4,:,2))';   %15
LOSS_AMVME(:,6) = squeeze(Vm_error_avg_inf_kron(5,:,2))';   %20
LOSS_AMVME(:,7) = squeeze(Vm_error_avg_inf_kron(6,:,2))';   %25

LOSS_AMVME(:,8) = squeeze(Vm_error_avg_inf_our(1,:,2))';    %0
LOSS_AMVME(:,9) = squeeze(Vm_error_avg_inf_our(2,:,2))';    %5
LOSS_AMVME(:,10) = squeeze(Vm_error_avg_inf_our(3,:,2))';    %10
LOSS_AMVME(:,11) = squeeze(Vm_error_avg_inf_our(4,:,2))';    %15
LOSS_AMVME(:,12) = squeeze(Vm_error_avg_inf_our(5,:,2))';    %20
LOSS_AMVME(:,13) = squeeze(Vm_error_avg_inf_our(6,:,2))';    %25

save('E:\Chaminda\7.State_Estimation_LotusGrove\V3_with_new_Krons\Error_with_loss\With_Comparision\Results\LOSS_AMVME.csv', 'LOSS_AMVME', '-ASCII','-append');

%% AVME
LOSS_AVME(:,1) = squeeze(Vm_error_avg_2_kron(1,:,1))';   %TRANSFORMER LOADING
LOSS_AVME(:,2) = squeeze(Vm_error_avg_2_kron(1,:,2))';   % 0.5l
LOSS_AVME(:,3) = squeeze(Vm_error_avg_2_kron(2,:,2))';   % 1l
LOSS_AVME(:,4) = squeeze(Vm_error_avg_2_kron(3,:,2))';   % 1.5l
LOSS_AVME(:,5) = squeeze(Vm_error_avg_2_kron(4,:,2))';   % 1.5l
LOSS_AVME(:,6) = squeeze(Vm_error_avg_2_kron(5,:,2))';   % 1.5l
LOSS_AVME(:,7) = squeeze(Vm_error_avg_2_kron(6,:,2))';   % 1.5l

LOSS_AVME(:,8) = squeeze(Vm_error_avg_2_our(1,:,2))';    % 0.5L
LOSS_AVME(:,9) = squeeze(Vm_error_avg_2_our(2,:,2))';    % 1L
LOSS_AVME(:,10) = squeeze(Vm_error_avg_2_our(3,:,2))';    % 1.5L
LOSS_AVME(:,11) = squeeze(Vm_error_avg_2_our(4,:,2))';    % 1.5L
LOSS_AVME(:,12) = squeeze(Vm_error_avg_2_our(5,:,2))';    % 1.5L
LOSS_AVME(:,13) = squeeze(Vm_error_avg_2_our(6,:,2))';    % 1.5L

save('E:\Chaminda\7.State_Estimation_LotusGrove\V3_with_new_Krons\Error_with_loss\With_Comparision\Results\LOSS_AVME.csv', 'LOSS_AVME', '-ASCII','-append');

%% AMCME
LOSS_AMCME(:,1) = squeeze(Im_error_avg_inf_kron(1,:,1))';   %TRANSFORMER LOADING
LOSS_AMCME(:,2) = squeeze(Im_error_avg_inf_kron(1,:,2))';   % 0.5l
LOSS_AMCME(:,3) = squeeze(Im_error_avg_inf_kron(2,:,2))';   % 1l
LOSS_AMCME(:,4) = squeeze(Im_error_avg_inf_kron(3,:,2))';   % 1.5l
LOSS_AMCME(:,5) = squeeze(Im_error_avg_inf_kron(4,:,2))';   % 1.5l
LOSS_AMCME(:,6) = squeeze(Im_error_avg_inf_kron(5,:,2))';   % 1.5l
LOSS_AMCME(:,7) = squeeze(Im_error_avg_inf_kron(6,:,2))';   % 1.5l


LOSS_AMCME(:,8) = squeeze(Im_error_avg_inf_our(1,:,2))';    % 0.5L
LOSS_AMCME(:,9) = squeeze(Im_error_avg_inf_our(2,:,2))';    % 1L
LOSS_AMCME(:,10) = squeeze(Im_error_avg_inf_our(3,:,2))';    % 1.5L
LOSS_AMCME(:,11) = squeeze(Im_error_avg_inf_our(4,:,2))';    % 1.5L
LOSS_AMCME(:,12) = squeeze(Im_error_avg_inf_our(5,:,2))';    % 1.5L
LOSS_AMCME(:,13) = squeeze(Im_error_avg_inf_our(6,:,2))';    % 1.5L
save('E:\Chaminda\7.State_Estimation_LotusGrove\V3_with_new_Krons\Error_with_loss\With_Comparision\Results\LOSS_AMCME.csv', 'LOSS_AMCME', '-ASCII','-append');


%% ACME
LOSS_ACME(:,1) = squeeze(Im_error_avg_2_kron(1,:,1))';   %TRANSFORMER LOADING
LOSS_ACME(:,2) = squeeze(Im_error_avg_2_kron(1,:,2))';   % 0.5l
LOSS_ACME(:,3) = squeeze(Im_error_avg_2_kron(2,:,2))';   % 1l
LOSS_ACME(:,4) = squeeze(Im_error_avg_2_kron(3,:,2))';   % 1.5l
LOSS_ACME(:,5) = squeeze(Im_error_avg_2_kron(4,:,2))';   % 1.5l
LOSS_ACME(:,6) = squeeze(Im_error_avg_2_kron(5,:,2))';   % 1.5l
LOSS_ACME(:,7) = squeeze(Im_error_avg_2_kron(6,:,2))';   % 1.5l

LOSS_ACME(:,8) = squeeze(Im_error_avg_2_our(1,:,2))';    % 0.5L
LOSS_ACME(:,9) = squeeze(Im_error_avg_2_our(2,:,2))';    % 1L
LOSS_ACME(:,10) = squeeze(Im_error_avg_2_our(3,:,2))';    % 1.5L
LOSS_ACME(:,11) = squeeze(Im_error_avg_2_our(4,:,2))';    % 1.5L
LOSS_ACME(:,12) = squeeze(Im_error_avg_2_our(5,:,2))';    % 1.5L
LOSS_ACME(:,13) = squeeze(Im_error_avg_2_our(6,:,2))';    % 1.5L
save('E:\Chaminda\7.State_Estimation_LotusGrove\V3_with_new_Krons\Error_with_loss\With_Comparision\Results\LOSS_ACME.csv', 'LOSS_ACME', '-ASCII','-append');
